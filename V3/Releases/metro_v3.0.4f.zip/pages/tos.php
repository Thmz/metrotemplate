<script>
menuLink = new Array(); 
menuColor = new Array();
$mainNav.set("home");
</script>
<h1 class="margin-t-0">Terms of Use</h1>
<p>This template is developped by Thomas Verelst and may only be used by people who donated to this project. If you have donated, you can stop reading here, you get a big thanks, and you can start customizing the template. To donate, go to <a href="http://metro-webdesign.info">Metro-Webdesign.info </a> and go to the donate page.
<h3>Why is this only for donators?</h3>
<p>I worked hard, very hard for v3 of this template. It has many features and getting this bug-free is really a pain in some browsers (Ahum, Internet Explorer). Also, I found optimizing this template very important. I used the latest techniques, with fallbacks for older browsers and I've optimized the javascript code as much as possible, I even added a compression system to ensure the performance of your site is good. I've tried to make this optimized for SEO (which isn't obvious for an AJAX template), and work on mobile phones with the mobile version. Also, writing tutorials isn't always fun and I also try to give support when you have a problem. You can ask support on the site.

<h3>Thanks to</h3>
<ul>
<li>The creators of jQuery</li>
<li>Brandon Aaron for his mousewheel plugin</li>
<li>Ben Alman for his jquery hashchange event</li>
<li>Tino Zijdel for his js minifier script</li>
</ul>
