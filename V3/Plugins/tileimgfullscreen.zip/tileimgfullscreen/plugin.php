<?php
$plBody .= "<div id='fullscreenbox'><div id='fullscreenwrapper'>
<img id='fullscreenimg' width='500'/>
<img id='fullscreenloader' src='img/loader.gif' width='32'>
<div id='fullscreenerror' class='grey'>Error: image not found</span></div></div>";
?>