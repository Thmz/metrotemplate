/* TILE IMG FULLSCREEN v0.2¨
how to use: set "clickforfullscreen" as optclass for a tile, and as linkPage argument you need to set "img:your/url.png", this will open the image at your/url.png
*/
$.plugin($afterTilesAppend,{
	fullscreenimg:function(){
		$(".clickforfullscreen","#content").each(function(){
			$(this).click(function(){
				var href = $(this).attr("href").replace("#!/img:","");
				
				$('#fullscreenbox').fadeIn(500);
				if(href==$("#fullscreenimg").attr("src")){
					$("#fullscreenloader").fadeOut(50,function(){
						$("#fullscreenimg").fadeIn(450);
					});
				}else{
					$("#fullscreenimg").attr("src",href).load(function(){
						$("#fullscreenloader").fadeOut(50,function(){
							$("#fullscreenimg").fadeIn(450);
						});
					}).error(function(){
						$("#fullscreenerror").fadeIn(500);
					})
				}
				$(document).unbind("mousewheel");	
				return false;
			});
		});
	}
})
$(document).on("click","#fullscreenbox",function(){
	$(this).fadeOut(400,function(){
		$("#fullscreenimg").hide();
		$("#fullscreenloader").show();
		$("#fullscreenerror").hide();
	});
	$(window).resize();
});