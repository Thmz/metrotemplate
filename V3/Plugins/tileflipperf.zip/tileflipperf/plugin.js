/*Performance flip tile 0.1 */
if(browser<11 || $.browser.opera){
	$(document).on("mouseenter",".tileFlipPerf",function(){
		$(this).removeClass("support3D").find(".flipFront, .tileLabelWrapper").stop().fadeOut(500);
	}).on("mouseleave",".tileFlipPerf",function(){
		$(this).find(".flipFront, .tileLabelWrapper").fadeIn(500);
	})
}else{
	$(document).on("mouseenter",".tileFlipPerf",function(){
		clearTimeout(timers["tileFlipPerfTimer"]);
		$(this).addClass("tileFlippedPerf");
	}).on("mouseleave",".tileFlipPerf",function(){
		timers["tileFlipPerfTimer"] = setTimeout(function(){$(".tileFlippedPerf").removeClass("tileFlippedPerf")},600);
	})
}
tileFlipPerf = function(group,x,y,width,height,bg,linkPage,img,content,labelSettings,optClass){ // make your own tiles
	$page.content += (
	"<a "+makeLink(linkPage)+" class='tileFlipPerf support3D tile group"+group+" "+optClass+"' style=' \
	margin-top:"+((y*$tile.scalespacing)+45)+"px;margin-left:"+(x*$tile.scalespacing+group*$group.spacing)+"px; \
	width: "+(width*$tile.scalespacing-$tile.spacing)+"px; height:"+(height*$tile.scalespacing-$tile.spacing)+"px;'>\
	<div class='flipContainer' style='border:1px solid "+bg+";'>\
		<div class='flipFront'><img src='"+img+"' style='width: "+(width*$tile.scalespacing-$tile.spacing)+"px; height:"+(height*$tile.scalespacing-$tile.spacing)+"px;'></div>\
		<div class='flipBack' style='background:"+bg+";'>"+content+"</div>\
	</div>\
	</a>");
}