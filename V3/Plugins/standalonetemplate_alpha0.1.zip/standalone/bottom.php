	<?php echo $plContentWrapper;?>
	</div>
	<div id="footer"><?php echo $siteFooter;?></div>
   <?php echo $plWrapper;?>  
</div> 
<?php echo $plBody;?>
</body>
</html>