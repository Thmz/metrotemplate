<?php include_once("standalone/top.php");?>
<div id="subNavWrapper">
	<div id="subNav">
    	<a style="background-color:#C33;" href="/#!/url" class="subNavItemActive">First submenu item</a>
        <a style="background-color:#C33;" href="/#!/otherurl">Another submenu</a>
        <a style="background-color:#C33;" href="/index.php">Third</a>
    </div>
</div>
<div id="content">

Some test content

</div>
<?php include_once("standalone/bottom.php");?>