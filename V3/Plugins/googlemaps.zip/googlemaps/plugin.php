<?php
//SETTINGS
$apiKey = "your-api-key"; // YOUR APl-key, check https://developers.google.com/maps/documentation/javascript/tutorial?hl=nl#api_key
// END OF SETTINGS

$plHead.='
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key='.$apiKey.'&sensor=false"></script>
';
?>