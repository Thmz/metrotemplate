/*SETTINGS*/
mapType = "ROADMAP"; //ROADMAP, SATELLITE, HYBRID or TERRAIN
xCor = -34.397 // x coordinate
yCor = 150.644 // y coordinate
zoomLvl = 8 // 0 (overview of the earth) - 18 (very close)
useKML = false;
KMLurl = "yoursite.com/file.kml"; // if useKML is true, specify the url to your KML file
doGeoLocation = false // uses geolocation if browser supports it, otherwise it'll use the coordinates specified above

/*END OF SETTINGS*/
tileGoogleMaps = function(group,x,y,width,height,bg,linkPage,content,labelSettings,optClass){ // make your own tiles
	if(labelSettings!='' && labelSettings[0] != ''){
		var label=labelSettings[0];
		var labelcolor=labelSettings[1];
		var labelposition=labelSettings[2];
		if(labelposition=='top'){
			var labelText ="<div class='tileLabelWrapper top' style='border-top-color:"+labelcolor+";'><div class='tileLabel top' >"+label+"</div></div>";
		}else{
			var labelText ="<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:"+labelcolor+";'>"+label+"</div></div>";
		}
	}else{
		labelText='';
	}
	$page.content += (
	"<a "+makeLink(linkPage)+" class='tile group"+group+" "+optClass+"' style=' \
	margin-top:"+((y*$tile.scalespacing)+45)+"px;margin-left:"+(x*$tile.scalespacing+group*$group.spacing)+"px; \
	width: "+(width*$tile.scalespacing-$tile.spacing)+"px; height:"+(height*$tile.scalespacing-$tile.spacing)+"px; \
	background:"+bg+";'>\
	<div id='google_maps'></div>\
	"+labelText+"\
	</a>");
}
$.plugin($afterTilesShow,{
	showMaps:function(){
		function initialize() {
			switch(mapType){		
				case "SATELLITE":
				mapType= google.maps.MapTypeId.SATELLITE
				break;
				case "HYBRID":
				mapType= google.maps.MapTypeId.HYBRID
				break;
				case "TERRAIN":
				mapType= google.maps.MapTypeId.TERRAIN
				break;
				default:
				case "ROADMAP":
				mapType= google.maps.MapTypeId.ROADMAP
				break;
			}
			var mapOptions = {
		    	zoom: zoomLvl,
			    center: new google.maps.LatLng(xCor, yCor),
		  	  mapTypeId: mapType
		  	}
			var map = new google.maps.Map(document.getElementById("google_maps"), mapOptions);
		    if(useKML){
     			var ctaLayer = new google.maps.KmlLayer(KMLurl);
     		 	ctaLayer.setMap(map);
    		}
		    if(doGeoLocation){
				if(navigator.geolocation) {// Try W3C Geolocation (Preferred)
			    	browserSupportFlag = true;
			    	navigator.geolocation.getCurrentPosition(function(position) {
						initialLocation = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
						map.setCenter(initialLocation);},function() {handleNoGeolocation(browserSupportFlag);});
				}else{// Browser doesn't support Geolocation
		    		browserSupportFlag = false;
				    handleNoGeolocation(browserSupportFlag);
				}
			}
		}
		setTimeout(function(){initialize()},100);
	}
});
