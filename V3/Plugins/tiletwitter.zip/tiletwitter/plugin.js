﻿tileTwitter = function(group,x,y,width,height,bg,linkPage,title,img,imgSize,imgToTop,imgToLeft,totaltweets,tweetsno,speed,screen_name,labelSettings,optClass){
//totaltweets can be a value of up to 3,200 of a user's most recent statuses
//tweetsno is the number of tweets displayed on a tile and can be a value of up to 5 and must be lower or equal to the totaltweets
		if(labelSettings!='' && labelSettings[0] != ''){
		var label=labelSettings[0];
		var labelcolor=labelSettings[1];
		var labelposition=labelSettings[2];
		if(labelposition=='top'){
			var labelText ="<div class='tileLabelWrapper top' style='border-top-color:"+labelcolor+";'><div class='tileLabel top' >"+label+"</div></div>";
		}else if(labelposition=='right'){
			var labelText ="<div class='tileLabelWrapper right'><div class='tileLabel right' style='border-bottom-color:"+labelcolor+";'>"+label+"</div></div>";
		}else{
			var labelText ="<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:"+labelcolor+";'>"+label+"</div></div>";
		}
	}else{
		labelText='';
	}
	var id= "twitter"+(group+''+x+''+y).replace(/\./g,'_');
	if(img!=''){
		imgInsert = "<img style='float:left; margin-top:"+imgToTop+"px;margin-left:"+imgToLeft+"px;' src='"+img+"' height="+imgSize+" width="+imgSize+"/>"
	}else{
		imgInsert = '';
		imgSize = 0;
		imgToLeft = 0;
	}
	$page.content += (
	"<a "+makeLink(linkPage)+" class='tile tileTwitter group"+group+" "+optClass+"' style=' \
	margin-top:"+((y*$tile.scalespacing)+45)+"px; margin-left:"+(x*$tile.scalespacing+group*$group.spacing)+"px; \
	width: "+(width*$tile.scalespacing-$tile.spacing)+"px; height:"+(height*$tile.scalespacing-$tile.spacing)+"px; \
	background:"+bg+";'>\
	"+imgInsert+"\
	<div class='tileTitle' style='margin-left:"+(imgSize+5+imgToLeft)+"px;'>"+title+"</div>\
	<div class='twitter' style='margin-left:"+(imgSize+10+imgToLeft)+"px;' id='"+id+"' ></div>\
	"+labelText+"\
	</a>");

	jQuery.getJSON("http://api.twitter.com/1/statuses/user_timeline/"+screen_name +".json?count="+totaltweets+"&callback=?",
	function twitterCallback2(twitters)
	{
 	   var statusHTML = [];
 	   var tweets = [];
 	   for (var i=0; i<twitters.length; i++)
 	   {
 	   		var username = twitters[i].user.screen_name;
 	   		var status = twitters[i].text.replace(/((https?|s?ftp|ssh)\:\/\/[^"\s\<\>]*[^.,;'">\:\s\<\>\)\]\!])/g, function(url)
 	   			{
 	   			  return '<a href="'+url+'">'+url+'</a>';
 	   			}).replace(/\B@([_a-z0-9]+)/ig, function(reply)
 	   			{
 	   			  return  reply.charAt(0)+'<a href="http://twitter.com/'+reply.substring(1)+'">'+reply.substring(1)+'</a>';
 	   			});
 	   			statusHTML.push('<li><span>'+status+'</span> <a style="font-size:85%" href="http://twitter.com/'+username+'/statuses/'+twitters[i].id_str+'">'+relative_time(twitters[i].created_at)+'</a></li>');
 	 	}
		if (totaltweets==tweetsno)
			{
			tweets = statusHTML;
			}
		else switch(tweetsno)
			{
			case 2:
				for (ss=0;ss<(totaltweets-1);ss++) {
				tweets[ss] = statusHTML[ss]+statusHTML[ss+1];
				}
				break;
			case 3:
				for (ss=0;ss<(totaltweets-2);ss++) {
				tweets[ss] = statusHTML[ss]+statusHTML[ss+1]+statusHTML[ss+2];
				}
				break;
			case 4:
				for (ss=0;ss<(totaltweets-3);ss++) {
				tweets[ss] = statusHTML[ss]+statusHTML[ss+1]+statusHTML[ss+2]+statusHTML[ss+3];
				}
				break;
			case 5:
				for (ss=0;ss<(totaltweets-4);ss++) {
				tweets[ss] = statusHTML[ss]+statusHTML[ss+1]+statusHTML[ss+2]+statusHTML[ss+3]+statusHTML[ss+4];
				}
				break;
			default:
				tweets = statusHTML;
				break;
			}		
  		
  		setTimeout(function(){newLiveTile(id,group,tweets,speed,0)},1500); // init this tile
		  //document.getElementById('twitter_update_list').innerHTML = statusHTML.join('');	
	});
	function relative_time(time_value) {
	  	var values = time_value.split(" ");
	  	time_value = values[1] + " " + values[2] + ", " + values[5] + " " + values[3];
	  	var parsed_date = Date.parse(time_value);
	  	var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
	  	var delta = parseInt((relative_to.getTime() - parsed_date) / 1000);
	  	delta = delta + (relative_to.getTimezoneOffset() * 60);
	
	  	if (delta < 60) {
	  	  return 'less than a minute ago';
	  	} else if(delta < 120) {
	  	  return 'about a minute ago';
	  	} else if(delta < (60*60)) {
	  	  return (parseInt(delta / 60)).toString() + ' minutes ago';
	  	} else if(delta < (120*60)) {
	  	  return 'about an hour ago';
	  	} else if(delta < (24*60*60)) {
	  	  return 'about ' + (parseInt(delta / 3600)).toString() + ' hours ago';
	  	} else if(delta < (48*60*60)) {
	  	  return '1 day ago';
	  	} else {
	  	  return (parseInt(delta / 86400)).toString() + ' days ago';
	  	}
	}
}