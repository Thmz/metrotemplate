<?php
/* TILERSS 0.1, can also be used as example how to pass PHP data (ex: mysql etc) to JAVASCRIPT and use it in tiles */
require_once('rss_php.php');    
$rss = new rss_php;
$rss->load('http://www.engadget.com/rss.xml'); // FILL IN THE LINK OF YOUR RSS FEED! THIS IS AN EXAMPLE TO CHECK ITS WORKING

$rssItems = $rss->getItems(); // CHECK http://rssphp.net/documentation/v1/#RSS_PHP.getRSS TO GET MORE DATA using the API

/* the str_replace below is to make sure there are no "-signs in the string because they would close the "" from javascript, leading into errors and bugs!! Every " is replaced by ' */
?>
<script>
	rssTitle1 = "<?php echo str_replace('"',"'",$rssItems[0]['title']);?>";
	rssTitle2 =  "<?php echo str_replace('"',"'",$rssItems[1]['title']);?>";
	rssTitle3 =  "<?php echo str_replace('"',"'",$rssItems[2]['title']);?>";
	rssTitle4 =  "<?php echo str_replace('"',"'",$rssItems[3]['title']);?>";
	rssTitle5 =  "<?php echo str_replace('"',"'",$rssItems[4]['title']);?>";
	rssDescription1 = "<?php echo str_replace('"',"'",$rssItems[0]['description']);?>";
	rssDescription2 =  "<?php echo str_replace('"',"'",$rssItems[1]['description']);?>";
	rssDescription3 =  "<?php echo str_replace('"',"'",$rssItems[2]['description']);?>";
	rssDescription4 =  "<?php echo str_replace('"',"'",$rssItems[3]['description']);?>";
	rssDescription5 =  "<?php echo str_replace('"',"'",$rssItems[4]['description']);?>";
</script>