$.plugin($onWindowResize,{
	resizeTiles:function(){
			var maxH = Math.max(($(document).height()-4),document.documentElement.clientHeight && $page.current == "home")
			if($(window).height()<maxH){
				var topMargin = $("#content").offset().top;
				var contentH = maxH-topMargin;
				var neededH = $(window).height()-topMargin;
				var scale = neededH/contentH;
				if(scale<0.8){
					scale=0.8;
				}else if(scale>1){
					scale = 1;
				}
				$("#contentWrapper").height(neededH);
				$("#content").css('-webkit-transform', 'scale('+Math.abs(scale)+','+Math.abs(scale)+')');
			}else{
				$("#content").css('-webkit-transform', 'none');
			}
	}
});