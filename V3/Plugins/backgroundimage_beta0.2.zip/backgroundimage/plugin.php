<?php
include_once("plugins/backgroundimage/settings.php");
$plBody.="<div style='background-image:url(".$bgImage.")' id='bg'><style>html{background-color:#000;}";
?>