maxBgScroll=150;
bgScrollSpeed = 500
$.plugin($onSiteLoad,{
	backgroundImage:function(){
		rightSpace = $("body>#bg").width()-$(window).width();
		bgScroll = rightSpace/$group.count;
		if(bgScroll>maxBgScroll){bgScroll=maxBgScroll;};
	    var oldGoTo = $group.goTo;
	    $group.goTo = function(n) {
      		oldGoTo(n);
			$('#bg').css("margin-left", -$group.current*bgScroll);
		}
	}
});
$.plugin($afterTilesAppend,{
	setBgPos:function(){
		$('#bg').css("margin-left", -$group.current*bgScroll);
	}
});
$.plugin($onWindowResize,{
	recalculateBgScroll:function(){
		rightSpace = $("body>#bg").width()-$(window).width();
		bgScroll = rightSpace/$group.count;
		if(bgScroll>maxBgScroll){bgScroll=maxBgScroll;};
		$('#bg').css("margin-left", -$group.current*bgScroll);
	}
});