<?php
$bgImage = "img/bg/stripes_blur.png";
?>