Requirements:
-Metro UI template v3.0.3 (!), full (/donator) version
-A fully working mobile site (http://yoururl.com/mobile.php )
-Mobile version enabled in config.php
-No-JS version enabled in config.php
-Go to http://yoururl.com/mobile.php to be sure the correct files are generated.


Installation: 
-rename your current index.php file to indexold.php
-place the index.php file of the zip into your root folder

