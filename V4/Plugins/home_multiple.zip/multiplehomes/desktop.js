multipleHomes = new Array("home","two","another"); // set your differnet "homepages" here!



$.plugin($hashChangeBegin,{
	multipleHomes:function(){
		if($hashed.parts[0]==""){
			if(typeof $hashed.parts[1] == "undefined" ||  $hashed.parts[1] == ""){
				$events.onTilesPrepare();
				$("#subNav").fadeOut(hideSpeed);
				$("#centerWrapper").fadeOut(hideSpeed,function(){
					$show.tiles();
					$("#tileContainer").children(".tile").css("visibility","visible").not(".home").css("visibility","hidden");
				}); 
				$hashed.doRefresh = false;
				setTimeout("$hashed.doRefresh=true",100);
			}else if(inArrayNCindex($hashed.parts[1],multipleHomes)!=-1){
				$events.onTilesPrepare();
				$("#subNav").fadeOut(hideSpeed);
				$("#centerWrapper").fadeOut(hideSpeed,function(){
					$show.tiles();
					$("#tileContainer").children(".tile").css("visibility","visible").not(".two").css("visibility","hidden");
				});
				$hashed.doRefresh = false;
				setTimeout("$hashed.doRefresh=true",100);
			}
		}
	}
});