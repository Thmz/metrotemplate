<?php
$bgImages = array("img/metro_slide.png","img/img2.jpg");
?>