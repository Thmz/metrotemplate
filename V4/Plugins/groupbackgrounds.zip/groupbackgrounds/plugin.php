<?php
include("settings.php");

function bgImagesInit(){
	global $bgImages;
	echo "<img src='".$bgImages[0]."'class='bgImage1' id='bgImage'/><img src='".$bgImages[1]."' class='bgImage2' id='bgImage'/>";
}
onEvent("bodyBegin","bgImagesInit");
$passToJS["bgImages"] = "bgImages";
?>