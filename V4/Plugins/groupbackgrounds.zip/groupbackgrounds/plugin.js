$.plugin($beforeTilesShow,{
	changeImage:function(){
		if(typeof bgImages[$group.current] != "undefined"){
			var $bg1 = $(".bgImage1");
			$(".bgImage2").attr("src",$bg1.attr("src")).show().fadeOut(500);
			$bg1.attr("src",bgImages[$group.current]);
		}
	}
});
$.plugin($tileGroupChangeBegin,{
	changeImage:function(){	
		if(typeof bgImages[$group.current] != "undefined"){
			var $bg1 = $(".bgImage1");
			$(".bgImage2").attr("src",$bg1.attr("src")).show().fadeOut(500);
			$bg1.attr("src",bgImages[$group.current]);
		}
	}
});