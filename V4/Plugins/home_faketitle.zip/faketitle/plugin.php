<?php
/* basic plugin template, see http://metro-webdesign.info/#!/tutorial for more info */


/*Do the things of our plugin */

$tileTypes['faketitle'] = array( /* Defaults*/
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>2,
	'height'=>1,
	"url"=>"",
	"text"=>"Title text",
	"classes"=>"",
);
function tile_faketitle($group,$x,$y,$width,$height,$url,$text,$classes){
	global $scale, $spacing, $scaleSpacing, $groupSpacing;
	$marginTop = $y*$scaleSpacing+getMarginTop($group)-45;
	$marginLeft = $x*$scaleSpacing+getMarginLeft($group);
	?>
  	<div class="groupTitle fakeTitle group<?php echo $group?> <?php echo $classes?>" style="
    margin-top:<?php echo $marginTop?>px; margin-left:<?php echo $marginLeft?>px;
	width:auto; height:auto;" <?php posVal($marginTop,$marginLeft,100);?>> 
    
    <a <?php echo makeLink($url);?> class="groupTitle" style="display:block;"><h3><?php echo $text?></h3></a>
    </div>
    <?php
}
?>