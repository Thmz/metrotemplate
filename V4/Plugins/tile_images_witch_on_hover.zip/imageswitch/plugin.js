/* Plugin JS file */
$(document).on("mouseover",".tileImageSwitch",function(){
	$(this).find(".back").stop().fadeIn(250);
}).on("mouseleave",".tileImageSwitch",function(){
	$(this).find(".back").stop().fadeOut(250);
})