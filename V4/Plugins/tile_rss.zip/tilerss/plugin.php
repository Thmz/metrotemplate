<?php
include_once("settings.php");

$tileTypes['RSS'] = array( /* Defaults*/
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>2,
	'height'=>1,
	"background"=>$defaultBackgroundColor,
	"url"=>"",
	"title"=>"Title",
	"feed"=>"http://www.thetimes.co.uk/tto/news/rss",
	"itemCount"=>3,
	"scroll"=>true,
	"titleLimit"=>150,
	"descLimit"=>60,
	"showDesc"=>true,
	"itemUrl"=>true,
	"img"=>"","imgAlt"=>"","imgTitle"=>"",
	"imgSize"=>"50",
	"imgToTop"=>"5",
	"imgToLeft"=>"5",
	"labelText"=>"",
	"labelColor"=>$defaultLabelColor,
	"labelPosition"=>$defaultLabelPosition,
	"classes"=>"",
);
function tile_RSS($group,$x,$y,$width,$height,$background,$url,$title,$feed,$itemCount,$scroll,$titleLimit,$descLimit,$showDesc,$itemUrl,$img,$imgAlt,$imgTitle,$imgSize,$imgToTop,$imgToLeft,$labelText,$labelColor,$labelPosition,$classes){
	global $scale, $spacing, $scaleSpacing, $groupSpacing;
	$marginTop = $y*$scaleSpacing+getMarginTop($group);
	$marginLeft = $x*$scaleSpacing+getMarginLeft($group);
	$tileWidth = $width*$scaleSpacing-$spacing;
	$tileHeight = $height*$scaleSpacing-$spacing;
	if($img == ""){$hasImg = 0;}else{$hasImg = 1;}
	
	if($itemUrl){
		echo "<div ";
	}else{
		echo "<a ";
	}
	echo makeLink($url);?> class="tile rssTile <?php if($scroll){echo "scroll";}?> group<?php echo $group?> <?php echo $classes?>" style="
    margin-top:<?php echo $marginTop?>px; margin-left:<?php echo $marginLeft?>px;
	width:<?php echo $tileWidth?>px; height:<?php echo $tileHeight?>px;
	background:<?php echo $background;?>;" <?php posVal($marginTop,$marginLeft,$tileWidth);?> data-count="0"> 
   	<div class='tileTitle' style='margin-left:<?php echo ($imgSize+$imgToLeft)*$hasImg+10;?>px;'><?php echo $title?></div>
    
    <?php
    require_once('rss_php.php');    
	$rss = new rss_php;
	$rss->load($feed);

	$rssItems = $rss->getItems(); // CHECK http://rssphp.net/documentation/v1/#RSS_PHP.getRSS TO GET MORE DATA using the API

	foreach($rssItems as $n=>$item){
		echo "<a ";
		if($itemUrl){echo "target='_blank' href='".$item["link"]."'";}
		echo " class='item'>";
		$t = $item['title'];
		if($titleLimit >0 && strlen($t)>$titleLimit){
			$t=substr($t,0,$titleLimit)."...";
		}
		$d = $item['description'];
		if($descLimit >0 && strlen($d)>$descLimit){
			$d=substr($d,0,$descLimit)."...";
		}
		echo "<div class='title'>&raquo ".$t."</div>";
		if($showDesc){
			echo "<div class='desc'>".$d."</div>";
		}
		echo "</a>";
		if($n+2>$itemCount){break;};
	}
	if($labelText!=""){
		if($labelPosition=='top'){
			echo "<div class='tileLabelWrapper top' style='border-top-color:".$labelColor.";'><div class='tileLabel top' >".$labelText."</div></div>";
		}else{
			echo "<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:".$labelColor.";'>".$labelText."</div></div>";
		}
	}
	if($itemUrl){
		echo "</div>";
	}else{
		echo "</a>";
	}
}
?>