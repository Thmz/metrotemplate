/* Plugin JS file */
$(document).ready(function(){
	$(".rssTile").each(function(){
		if($(this).hasClass("scroll")){	
			$(this).children(".item:not(:first)").hide();
			
		}
	});
	setTimeout("refreshRSS();",5000)
}); 
function refreshRSS(){
	if(device == "mobile" || $page.current=="home"){
	$(".rssTile").each(function(){
		if($(this).hasClass("scroll")){	
			var n = $(this).data("count");
			if(n>=$(this).children(".item").length){n=0;};
			$(this).children(".item").eq(n).css({opacity:1,marginTop:0}).animate({opacity:0,marginTop:20},500);
			var m = n+1;
			if(m>=$(this).children(".item").length){m=0;};
			$(this).children(".item").eq(m).show().css({opacity:0,marginTop:-20}).show().animate({opacity:1,marginTop:0},500);
			$(this).data("count",n+1)
		}
	});
}
	setTimeout("refreshRSS();",5000)
}