$.plugin($afterSubPageShow,{
	goToAnchor:function(){
		for(var i =1;i<$hashed.parts.length;i++){
			var v="a";
			if($hashed.parts[i].substr(0,(v.length+1)) == v+"="){
				var t = $hashed.parts[i].substr(v.length+1); 
				if($("#"+t).length>0){
					$("html, body").animate({scrollTop:$("#"+t).offset().top},500)
				}
			}
		}	
	}
});