<?php
/* METRO UI panels plugin v0.1 - SETTINGS*/

$panelLeftWidth = 400; // in px
$panelLeftColor = "#444";
$panelLeftDim = 0.6; // dim the screen when a sidepanel is opened, set to 0 or false to disable, set to a value between 0 and 1 to define the opacity
$panelLeftGroupScrolling = false; // should it be possible to scroll gruops when the panel is opened? If set to false, the middlemouse scroll won't trigger the groupscrolling. 

$hidePanelLeftOnClick = true; // hides the panel on a click outside the panel

$preloadedPanelsLeft = array();
?>