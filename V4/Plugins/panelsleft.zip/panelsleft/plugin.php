<?php
/* panel plugin */
include("settings.php");


if($panelLeftDim){
	function dimPanelLeftFunc(){
	echo "<style>
		#catchScroll{
			background:rgb(30,30,30);
			-ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=00)';
			filter: alpha(opacity=00);
			-moz-opacity: 0;
			-khtml-opacity: 0;
			opacity:0;
		}
		</style>";
	}
	onEvent("headEnd","dimPanelLeftFunc");
}
function panelLeft(){
	global $theme,$panelLeftWidth, $panelLeftColor, $panelLeftDim, $preloadedPanelsLeft;
	echo "<div id='panelLeft' style='max-width:".$panelLeftWidth."px;right:-".$panelLeftWidth."px;background-color:".$panelLeftColor.";'>
	<img id='panelLeftArrow' src='themes/".$theme."/img/panels/arrow.png' onClick='javascript:hidePanelLeft();' alt='hide panel'>
	<img id='panelLeftLoader' src='themes/".$theme."/img/panels/loader.gif' alt='Loading...'>
	<div id='panelLeftContent'>
	</div>
	";
	
	foreach($preloadedPanelsLeft as $panelLeft){
		if(file_exists("panels/".$panelLeft)){
			echo "<div class='preloadedPanelLeft' id='panel_".str_replace("%","_",urlencode(str_replace("/","_slash-",str_replace(".","_",$panel))))."'>";
			include("lpanels/".$panelLeft);
			echo "</div>";
		}
	}
	echo"</div>";
}
onEvent('bodyEnd','panelLeft');

$passToJS["panelLeftDim"] = "panelLeftDim";
$passToJS['hidePanelLeftOnClick'] = 'hidePanelLeftOnClick';
$passToJS['panelLeftGroupScrolling'] = 'panelLeftGroupScrolling';


?>