$(document).on("click","a[href^='lpanels/']",function(event){
	event.preventDefault();
	$this = $(this);
	$panel = $("#panelLeft");
	
	$panel.stop().show().animate({left:0},500, "easeOutCubic");
	$("#panelLeftLoader").show()
	
	if($("#panel_"+encodeURIComponent($this.attr("href").replace(/./g,"_").replace(/\//g,"_slash-")).replace(/%/g,"_")).length>0){
		$("#panelLeftContent, .preloadedPanelLeft, #panelLeftLoader").hide();
		$("#panel_"+encodeURIComponent($this.attr("href").replace(/./g,"_").replace(/\//g,"_slash-")).replace(/%/g,"_")).fadeIn(300);
		if(panelDim){
			$("#catchScroll").animate({opacity:panelLeftDim},500).css("z-index",49);
		};
		if(!panelLeftGroupScrolling){
			scrolling=true;
		}
		transformLinks();
		$events.sidepanelShow();
	}else{
		$.ajax($this.attr("href")).success(function(newContent,textStatus){	
			$("#panelLeftContent, .preloadedPanelLeft").hide()
			$("#panelLeftLoader").fadeOut(200)
			$("#panelLeftContent").html(newContent).fadeIn(300);
			if(panelLeftDim){
				$("#catchScroll").animate({opacity:panelLeftDim},500).css("z-index",49);
			};
			if(!panelLeftGroupScrolling){
				scrolling=true;
			}
			transformLinks();
			$events.sidepanelShow();
		});
	}	
	if(hidePanelLeftOnClick){
		$(document).bind("click.hidepanelleft",function(){
			hidePanelLeft();
			$(document).unbind("click.hidepanelleft");
		});
		 $panel.click(function(event){
	    	 event.stopPropagation();
	 	});
	}
	
	return false;
});
hidePanelLeft = function(){
	$("#panelLeft").animate({left:-$("#panelLeft").width()-20},500,"easeOutCubic",function(){
		$(this).hide();
		if(!panelLeftGroupScrolling){
			scrolling=false;
		}
	});
	$("#catchScroll").animate({opacity:0},500).css("z-index",-1);
	$events.sidepanelHide();
}