/*tileMosaic = function(group,x,y,width,height,bg,linkPage,images,imgbgcolor,labelSettings,optClass){ // make your own tiles
	if(labelSettings!='' && labelSettings[0] != ''){
		var label=labelSettings[0];
		var labelcolor=labelSettings[1];
		var labelposition=labelSettings[2];
		if(labelposition=='top'){
			var labelText ="<div class='tileLabelWrapper top' style='border-top-color:"+labelcolor+";'><div class='tileLabel top' >"+label+"</div></div>";
		}else{
			var labelText ="<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:"+labelcolor+";'>"+label+"</div></div>";
		}
	}else{
		labelText='';
	}
	
	var il = images.length;
	var m = 4;
	fimg = "";
	bimg = "";
	var backimgcss = " style='background-image:url("+images[0]+")' "
	if(il==3){
		fimg = "<img id='tileMosaic4_1' src='"+images[1]+"'/><img id='tileMosaic4_4' src='"+images[2]+"'/>"
		bimg = "<div id='tileMosaic4_1b' "+backimgcss+"></div><div id='tileMosaic4_4b' "+backimgcss+"></div>"
	}else if(il==4){
		fimg = "<img id='tileMosaic4_1' src='"+images[1]+"'/><img id='tileMosaic4_2' src='"+images[2]+"'/><img id='tileMosaic4_4' src='"+images[3]+"'/>"
		bimg = "<div id='tileMosaic4_1b' "+backimgcss+"></div><div id='tileMosaic4_2b' "+backimgcss+"></div><div id='tileMosaic4_4b' "+backimgcss+"></div>"
	}else if(il==5){
		fimg = "<img id='tileMosaic4_1' src='"+images[1]+"'/><img id='tileMosaic4_2' src='"+images[2]+"'/><img id='tileMosaic4_3' src='"+images[3]+"'/><img id='tileMosaic4_4' src='"+images[4]+"'/>"
		bimg = "<div id='tileMosaic4_1b' "+backimgcss+"></div><div id='tileMosaic4_2b' "+backimgcss+"></div><div id='tileMosaic4_3b' "+backimgcss+"></div><div id='tileMosaic4_4b' "+backimgcss+"></div>"
	}else if(il>5){
		m=9;
		for(i=1;i<il;i++){
			fimg += "<img id='tileMosaic9_"+i+"' src='"+images[i]+"'>";
			bimg += "<div id='tileMosaic9_"+i+"b' "+backimgcss+"></div>";
		}
	}
	
	var widthpx = (width*$tile.scalespacing-$tile.spacing);
//	if(m==4){
		function isEven(v){if(v%2==0){return true;}else{return false;}}		
		if(!isEven(widthpx)){ // make the number even, otherwise there's a white gap between imgs
			widthpx++;
		}
	//}else{
		//function isDivBy3(v){if(v%3==0){return true;}else{return false;}}
		//if(!isDivBy3(widthpx)){ // make the dividable by 3, otherwise gaps
		//	widthpx == Math.round(widthpx/3)*3;
		//}
	//}
	var heightpx=widthpx;
	$page.content += (
	"<style>.tileMosaic img, .tileMosaic>#b_container>div{background-color:"+imgbgcolor+";}</style>\
	<a "+makeLink(linkPage)+" class='tile group"+group+" tileMosaic "+optClass+"' style=' \
	margin-top:"+((y*$tile.scalespacing)+45)+"px;margin-left:"+(x*$tile.scalespacing+group*$group.spacing)+"px; \
	width: "+widthpx+"px; height:"+heightpx+"px; \
	background:"+bg+";'>\
	<div id='f_container' class='f_container"+m+"'>"+fimg+"</div>\
	<div id='b_container' class='b_container"+m+"'>"+bimg+"</div>\
	"+labelText+"\
	</a>");
	setTimeout(function(){tileMosaicFlip(images.length,0,m,[]);},2000);
	
}*/

tileMosaicFlip = function(length,r,m,af){
	var f = false;
	var i = 0;
	var s = 300;
	while(!f){	
		var g = Math.floor((Math.random()*m)+1);
		if($.inArray(g,af)==-1){f=true;}
		i++;
		if(i>length){f=true;g=0;}
	}	
	af.push(g);
	$id = $("#tileMosaic"+m+"_"+g);
	$id_back = $("#tileMosaic"+m+"_"+g+"b");
	if(r==0){ // if big image is front now
		var margin = $id_back.width()/2;
		var height= $id_back.width();
		$id_back.css({height:''+height+"px",marginTop:'0px'});
		$id.css({height:'0px',marginTop:''+margin+'px'});
		$id_back.animate({height:'0px',marginTop:''+margin+'px'},250,function(){
			$id.animate({height:''+height+'px',marginTop:'0px'},250);
		});	
		if(af.length>length){
			af = new Array();
			r=1;
			s=650;
		}
	}else{
		var margin = $id.width()/2;
		var height= $id.width();
		$id.css({height:''+height+"px",marginTop:'0px'});
		$id_back.css({height:'0px',marginTop:''+margin+'px'});
		$id.animate({height:'0px',marginTop:''+margin+'px'},250,function(){
			$id_back.animate({height:height+'px',marginTop:'0px'},250);
		});
		if(af.length>length){
			af = new Array();
			r=0;
			s=1000;
		}
	}
	setTimeout(function(){tileMosaicFlip(length,r,m,af)},s);
}