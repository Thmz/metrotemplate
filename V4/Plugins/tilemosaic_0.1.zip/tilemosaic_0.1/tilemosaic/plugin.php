<?php
/* basic plugin template, see http://metro-webdesign.info/#!/tutorial for more info */

/* Define your defaults here */
/*Do the things of our plugin */

$tileTypes['mosaic'] = array( /* Defaults*/
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>1,
	'height'=>1,
	"background"=>$defaultBackgroundColor,
	"url"=>"",
	"img"=>array(),
	"imgbgcolor"=>"#DDD",
	"labelText"=>"",
	"labelColor"=>$defaultLabelColor,
	"labelPosition"=>$defaultLabelPosition,
	"classes"=>"",
);
function tile_mosaic($group,$x,$y,$width,$height,$background,$url,$img,$imgbgcolor,$labelText,$labelColor,$labelPosition,$classes){
	global $scale, $spacing, $scaleSpacing, $groupSpacing;
	$marginTop = $y*$scaleSpacing+getMarginTop($group);
	$marginLeft = $x*$scaleSpacing+getMarginLeft($group);
	$tileWidth = $width*$scaleSpacing-$spacing;
	$tileHeight = $height*$scaleSpacing-$spacing;
	if($tileWidth&1){
		$tileWidth++;
	}
	
	$il = count($img);
	$m = 4;
	$fimg = "";
	$bimg = "";
	$backimgcss = " style='background-image:url(".$img[0].")'";
	
	if($il==3){
		$fimg = "<img id='tileMosaic4_1' src='".$img[1]."'/><img id='tileMosaic4_4' src='".$img[2]."'/>";
		$bimg = "<div id='tileMosaic4_1b' ".$backimgcss."></div><div id='tileMosaic4_4b' ".$backimgcss."></div>";
	}else if($il==4){
		$fimg = "<img id='tileMosaic4_1' src='".$img[1]."'/><img id='tileMosaic4_2' src='".$img[2]."'/><img id='tileMosaic4_4' src='".$img[3]."'/>";
		$bimg = "<div id='tileMosaic4_1b' ".$backimgcss."></div><div id='tileMosaic4_2b' ".$backimgcss."></div><div id='tileMosaic4_4b' ".$backimgcss."></div>";
	}else if($il==5){
		$fimg = "<img id='tileMosaic4_1' src='".$img[1]."'/><img id='tileMosaic4_2' src='".$img[2]."'/><img id='tileMosaic4_3' src='".$img[3]."'/><img id='tileMosaic4_4' src='".$img[4]."'/>";
		$bimg = "<div id='tileMosaic4_1b' ".$backimgcss."></div><div id='tileMosaic4_2b' ".$backimgcss."></div><div id='tileMosaic4_3b' ".$backimgcss."></div><div id='tileMosaic4_4b' ".$backimgcss."></div>";
	}else if($il>5){
		$m=9;
		for($i=1;$i<$il;$i++){
			$fimg .= "<img id='tileMosaic9_".$i."' src='".$img[$i]."'>";
			$bimg .= "<div id='tileMosaic9_".$i."b' ".$backimgcss."></div>";
		}
	}
	?>
  	<a <?php echo makeLink($url);?> class="tile tileMosaic group<?php echo $group?> <?php echo $classes?>" style="
    margin-top:<?php echo $marginTop?>px; margin-left:<?php echo $marginLeft?>px;
	width:<?php echo $tileWidth?>px; height:<?php echo $tileHeight?>px;
	background:<?php echo $background;?>;" <?php posVal($marginTop,$marginLeft,$tileWidth);?>> 
    
    
    <div id='f_container' class='f_container<?php echo $m?>'><?php echo $fimg?></div>
	<div id='b_container' class='b_container<?php echo $m?>'><?php echo $bimg?></div>
    <script>setTimeout(function(){tileMosaicFlip(<?php echo $il?>,0,<?php echo $m?>,[]);},2000);</script>
    <?php 
	if($labelText!=""){
		if($labelPosition=='top'){
			echo "<div class='tileLabelWrapper top' style='border-top-color:".$labelColor.";'><div class='tileLabel top' >".$labelText."</div></div>";
		}else{
			echo "<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:".$labelColor.";'>".$labelText."</div></div>";
		}
	}
	?> 
    </a>
    <?php
}
?>