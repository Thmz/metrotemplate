drop the tilemosaic folder that's inside the zip into your /plugins/ dir. Add a tile in config/tiles.php with this example syntax:

$tile[]= array(
	"type"=>"mosaic",
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>1,
	'height'=>1,
	"background"=>"#DDD",
	"url"=>"",
	"img"=>array("img/chars/a_color.png","img/a.png","img/b.png","img/c.png","img/d.png"),
	"imgbgcolor"=>"#DDD",
	"classes"=>""
);


add as many images as you want to the img array (up to 10, the first url is the url of the big front image). The plugin will change it's layout to the number of images.