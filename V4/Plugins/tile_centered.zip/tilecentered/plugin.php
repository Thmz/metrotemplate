<?php
/*Centered + centered slide plugin v0.1-*/

$tileTypes['centered'] = array( /* Defaults*/
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>2,
	'height'=>1,
	"background"=>$defaultBackgroundColor,
	"backgroundHover"=>"",
	"color"=>"#FFF",
	"colorHover"=>"",
	"url"=>"",
	"title"=>"Example",
	"img"=>"","imgAlt"=>"","imgTitle"=>"",
	"imgSize"=>"50",
	"imgToTop"=>"0",
	"imgToLeft"=>"0",
	"labelText"=>"",
	"labelColor"=>$defaultLabelColor,
	"labelPosition"=>$defaultLabelPosition,
	"classes"=>"",
);
function tile_centered($group,$x,$y,$width,$height,$background,$backgroundHover,$color,$colorHover,$url,$title,$img,$imgAlt,$imgTitle,$imgSize,$imgToTop,$imgToLeft,$labelText,$labelColor,$labelPosition,$classes){
	global $scale, $spacing, $scaleSpacing, $groupSpacing;
	$marginTop = $y*$scaleSpacing+getMarginTop($group);
	$marginLeft = $x*$scaleSpacing+getMarginLeft($group);
	$tileWidth = $width*$scaleSpacing-$spacing;
	$tileHeight = $height*$scaleSpacing-$spacing;
	?>
  	<a <?php echo makeLink($url);?> class="tile tileCentered group<?php echo $group?> <?php echo $classes?>" style="
    margin-top:<?php echo $marginTop?>px; margin-left:<?php echo $marginLeft?>px;
	width:<?php echo $tileWidth?>px; height:<?php echo $tileHeight?>px;background:<?php echo $background;?>;"
	<?php posVal($marginTop,$marginLeft,$tileWidth);?>	> 
    <div class="container" style="background:<?php echo $background;?>;"
    <?php if($backgroundHover != ""){
		?>
		onMouseOver="javascript:$(this).css('background','<?php echo $backgroundHover?>')"
		onMouseOut="javascript:$(this).css('background','<?php echo $background;?>')"
		<?php
	}?>
	>
    <h3 style='color:<?php echo $color?>'

    <?php if($colorHover != ""){
		?>
		onMouseOver="javascript:$(this).css('color','<?php echo $colorHover?>')"
		onMouseOut="javascript:$(this).css('color','<?php echo $color?>')"
		<?php
	}?>
    >
     <?php if($img != ""){?>
    <img title='<?php echo $imgTitle?>' alt='<?php echo $imgAlt?>' style='margin-top:<?php echo $imgToTop?>px;margin-left:<?php echo $imgToLeft?>px;' 
    src='<?php echo $img?>' height="<?php echo $imgSize?>" width="<?php echo $imgSize?>"/>
    <?php } ?>

    <?php echo $title;?>
    </h3>
    
    </div>

    <?php 
	if($labelText!=""){
		if($labelPosition=='top'){
			echo "<div class='tileLabelWrapper top' style='border-top-color:".$labelColor.";'><div class='tileLabel top' >".$labelText."</div></div>";
		}else{
			echo "<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:".$labelColor.";'>".$labelText."</div></div>";
		}
	}
	?>
	
    </a>
    <?php

}

$tileTypes['centeredSlide'] = array( /* Defaults*/
	"group"=>0,
	"x"=>0,
	"y"=>0,
	'width'=>2,
	'height'=>1,
	"background"=>$defaultBackgroundColor,
	"url"=>"",
	"title"=>"Example",
	"text"=>"This text will show up when hovered",
	"direction"=>"left", /* top, right, bottom, left*/
	"img"=>"","imgAlt"=>"","imgTitle"=>"",
	"imgSize"=>"50",
	"imgToTop"=>"0",
	"imgToLeft"=>"0",
	"labelText"=>"",
	"labelColor"=>$defaultLabelColor,
	"labelPosition"=>$defaultLabelPosition,
	"classes"=>"",
);
function tile_centeredSlide($group,$x,$y,$width,$height,$background,$url,$title,$text,$direction, $img,$imgAlt,$imgTitle,$imgSize,$imgToTop,$imgToLeft,$labelText,$labelColor,$labelPosition,$classes){
	global $scale, $spacing, $scaleSpacing, $groupSpacing;
	$marginTop = $y*$scaleSpacing+getMarginTop($group);
	$marginLeft = $x*$scaleSpacing+getMarginLeft($group);
	$tileWidth = $width*$scaleSpacing-$spacing;
	$tileHeight = $height*$scaleSpacing-$spacing;
	?>
  	<a <?php echo makeLink($url);?> class="tile tileCenteredSlide <?php echo $direction;?> group<?php echo $group?> <?php echo $classes?>" style="
    margin-top:<?php echo $marginTop?>px; margin-left:<?php echo $marginLeft?>px;
	width:<?php echo $tileWidth?>px; height:<?php echo $tileHeight?>px;
	background:<?php echo $background;?>;" <?php posVal($marginTop,$marginLeft,$tileWidth);?>
	> 
    
    <div class="container1">
    	<h3>
     	<?php if($img != ""){?>
    	<img title='<?php echo $imgTitle?>' alt='<?php echo $imgAlt?>' style='margin-top:<?php echo $imgToTop?>px;margin-left:<?php echo $imgToLeft?>px;' 
    	src='<?php echo $img?>' height="<?php echo $imgSize?>" width="<?php echo $imgSize?>"/>
    	<?php } ?>

	    <?php echo $title;?>
    	</h3>
    	</div>
    <div class="container2">
    	<h5><?php echo $text;?></h5>
    </div>
    <?php 
	if($labelText!=""){
		if($labelPosition=='top'){
			echo "<div class='tileLabelWrapper top' style='border-top-color:".$labelColor.";'><div class='tileLabel top' >".$labelText."</div></div>";
		}else{
			echo "<div class='tileLabelWrapper bottom'><div class='tileLabel bottom' style='border-bottom-color:".$labelColor.";'>".$labelText."</div></div>";
		}
	}
	?>
	
    </a>
    <?php
}
?>