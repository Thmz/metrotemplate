<?php
/*Device detection */


/* Premium feature... */
$device = 'desktop';
$mobile = false;
?>