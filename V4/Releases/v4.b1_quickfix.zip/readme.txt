-For Metro UI template v4.b1

-unpack the "js" and "plugins" dir into your root so it merges. Overwrite the existing files.
