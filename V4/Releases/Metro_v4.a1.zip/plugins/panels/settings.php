<?php
/* METRO UI panels plugin v0.1 - SETTINGS*/

$panelWidth = 400; // in px
$panelColor = "#444";

$hidePanelOnClick = true; // hides the panel on a click outside the panel

$preloadedPanels = array("");
?>