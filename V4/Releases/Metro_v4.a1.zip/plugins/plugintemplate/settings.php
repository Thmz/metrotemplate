<?php
/* Settings for plugin */
?>