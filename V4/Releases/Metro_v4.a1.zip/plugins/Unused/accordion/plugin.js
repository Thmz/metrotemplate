$.plugin($beforeSubPageShow,{
	accordion:function(){
		$("div.metro-accordion").children("h3").each(function(){
			$(this).next().addClass("accordionContent").hide();
			$(this).prepend("<img class='accordionArrow' src='img/arrows/arrowRight.png'/>");
		});
		$("div.metro-accordion").on("click","h3",function(){
			var $c = $(this).next(),
				$d = $(this).parent();
			if($c.css("display") == "none"){
				if($d.hasClass("hide-others")){
					$d.children("div").stop().slideUp(500);
					$d.children("h3").children("img").attr("src","img/arrows/arrowRight.png").removeClass('down').addClass("right");
					if($.layout.name == "webkit"){
						r=0;
						$accordion.turnImageRight($d.children("h3").children("img"));
					}
				}
				$c.stop().slideDown(500);
				if($.browser.name=="msie" && $.browser.version<9){
					$(this).children("img").attr("src","img/arrows/arrowBottom.png")
				}else if($.layout.name == "webkit"){	
					r=0;
					$accordion.turnImageDown($(this).children("img"));
				}else{
					$(this).children("img").removeClass('right').addClass("down");
				}
			}else{
				$c.stop().slideUp(500);
				if($.browser.name=="msie" && $.browser.version<9){
					$(this).children("img").attr("src","img/arrows/arrowRight.png")
				}else if($.layout.name == "webkit"){
					r=90;
					$accordion.turnImageRight($(this).children("img"));
				}else{
					$(this).children("img").removeClass('down').addClass("right");					
				}	
			}
		});
	}
});
$accordion={
	turnImageDown:function(img){
	    r+=9;
		$accordion.turn(img,r);
	    if(r<90){setTimeout(function(){$accordion.turnImageDown(img)},40)}else{setTimeout(function(){$accordion.turn(img,90)},40)}
	},
	turnImageRight: function(img){
	    r-=9;
	    $accordion.turn(img,r);
	    if(r>0){setTimeout(function(){$accordion.turnImageRight(img)},40)}else{setTimeout(function(){$accordion.turn(img,0)},40)}
	},
	turn:function(img,r){
	    img.css("transform","rotate("+r+"deg)").css("-webkit-transform","rotate("+r+"deg)")
	}
}