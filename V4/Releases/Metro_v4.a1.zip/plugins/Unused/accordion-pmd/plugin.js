$.plugin($beforeSubPageShow,{
	accordion:function(){
		$("div.metro-accordion").children("h3").each(function(){
			$(this).next().addClass("accordionContent").hide();
			$(this).prepend("<img class='accordionArrow' src='img/arrows/arrowRight.png'/>");
		});
		$("div.metro-accordion").on("click","h3",function(){
			var $c = $(this).next(),
				$d = $(this).parent();
			if($c.css("display") == "none"){
				if($d.hasClass("hide-others")){
					$d.children("div").stop().slideUp(500);
					$d.children("h3").children("img").attr("src","img/arrows/arrowRight.png").removeClass('down').addClass("right");
				}
				$c.stop().slideDown(500);
				if($.browser.name=="msie" && $.browser.version <9){$(this).children("img").attr("src","img/arrows/arrowBottom.png")};
				$(this).children("img").removeClass('right').addClass("down");
				
			}else{
				$c.stop().slideUp(500);
				if($.browser.name=="msie" && $.browser.version <9){$(this).children("img").attr("src","img/arrows/arrowRight.png")};
				$(this).children("img").removeClass('down').addClass("right");
			}
		});
	}
});
