<a id="group0">
	<img src="img/icons/home.png" alt="home"/>
	Home
</a>
<a id="group1">
	<img src="img/icons/download_s.png" alt="Tilegroup 2"/>
	Tilegroup 2
 </a>
<a id="group2">
	<img src="img/icons/questionmark.png" alt="Group 3"/>
	Group 3
</a>