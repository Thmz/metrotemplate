<?php
/* basic plugin template, see http://metro-webdesign.info/#!/tutorial for more info */

/* Define your defaults here */

/*Now, get the settings of the user */
include_once("settings.php");

/*Do the things of our plugin */
?>