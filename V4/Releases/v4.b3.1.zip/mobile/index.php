<?php
header("Location: ../mobile.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta HTTP-EQUIV="REFRESH" content="0; url=../mobile.php">
<title>Redirecting...</title>
<style>
body{
	background-color:#CCC;
	font-family:Verdana, Geneva, sans-serif;
	font-weight:lighter;
}
#link{
	text-decoration:none;color:#333;
	font-weight:100;
}
#link:hover{
	color:#F60;
}
</style>
</head>
<body>
<div style="margin:50px auto;width:300px;">
<a id="link" href="../mobile.php" style=""><span style="font-size:30px;">You are being redirected</span><br>click here to continue</a></div>
</body>
</html>