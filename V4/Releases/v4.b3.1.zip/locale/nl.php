<?php
/* For V4.b2 */
$l_menu = "Menu";
$l_home = "Home";

$l_pageNotFound = "404 - Pagina niet gevonden";
$l_pageNotFoundDesc = "<h2 class='margin-t-0'>404 - Pagina niet gevonden</h2>Onze excuses, de pagina waar je naar op zoek bent bestaat niet meer.";



$l_goToMobileSite = "Ga naar de mobiele site";
$l_goToFullSite = "Ga naar de volledige site";
$l_goToFullSiteRedirect = "Je wordt doorgestuurd naar de volledige site";
?>