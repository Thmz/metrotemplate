<h1>Example sidepanel</h1>
<?php
set_include_path("../");

/*Include sidebar */
include("inc/sidebar.php");
showSidebar("an_example");
?>
<p style='margin-top:250px;'>See the source how we've put this sidebar in a panel!</p>
