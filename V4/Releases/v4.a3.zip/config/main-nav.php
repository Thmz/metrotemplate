<a rel="group0">
	<img src="img/icons/home.png"/>
	Home
</a>
<a rel="group1">
	<img src="img/icons/download_s.png"/>
	Tilegroup 2
 </a>
<a rel="group2">
	<img src="img/icons/questionmark.png"/>
	Group 3
</a>