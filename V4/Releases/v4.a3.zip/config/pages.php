<?php
/*
All pages you have in the /pages/ folder must be defined here, it's their own title (shown on top and in the url)

ex: $pageTitles['file.php'] = "This is the title";

Just copy paste this and fill in :

$pageTitles[''] = "";

/* PAGE OPTIONS */

$pageTitles['welcome.php'] = "Welcome";
$pageTitles['typography.php'] = "Typography";
$pageTitles['accordions.php'] = "Accordions";
$pageTitles['sidebars.php'] = "Sidebars";
?>