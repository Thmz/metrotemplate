<?php
$username= "username";
$password= "password";
?>