$(document).ready(function(){
	logout = function(){if(confirm("Are you sure you want to log out?")){window.location.href="logout.php";};}
});