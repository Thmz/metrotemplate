<?php
$username= "Thomas";
$password= "thomasadminpass";
?>