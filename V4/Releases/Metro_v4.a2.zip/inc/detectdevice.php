<?php
/*Device detection */
include_once('inc/mobile_device.php');
$detect = new Mobile_Detect();
$tablet = $detect->isTablet();
$mobile = $detect->isMobile();
$device = "desktop";
if($mobile){
	$device = "mobile";
}
if($tablet){
	$device = "tablet";
}
if($enableMobile){
	if ($redirectPhone && $mobile  && ((!$redirectTablet  && !$tablet) || ($redirectTablet && $tablet))){ //Redirect if needed, according to settings
		if(!isset($_COOKIE['fullsite']) || $_COOKIE['fullsite'] != 1){
			header("Location: mobile.php");
		}else{
			$device = "mobileOnDesktop";
		}
	}
}
$mobile = false;
?>