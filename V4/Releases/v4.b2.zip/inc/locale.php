<?php
$l_menu = "Menu";
$l_home = "Home";

$l_pageNotFound = "404 - Page not Found";
$l_pageNotFoundDesc = "<h2 class='margin-t-0'>404 - Page not Found</h2>We're sorry, the page you're looking for is not found.";



$l_goToMobileSite = "Go to mobile site";
$l_goToFullSite = "Go to full site";
$l_goToFullSiteRedirect = "You'll be redirected to the full site";
?>