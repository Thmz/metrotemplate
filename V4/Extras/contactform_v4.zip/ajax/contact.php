<?php
$email = $_POST['email'];
$test = $_POST['test'];
$message = $_POST['message'];
if($test != "1234"){
	die("You must fill in 1234 without apotrophes!");
}else if(strlen($email)<4){
	die("Emailadress is not valid!");
}
$message = wordwrap($message,60);
mail("thomas.verelst@hotmail.com","Metro UI template", $message."\n\n Sent from: ".$email, "From: $email");
echo "yes";
?>