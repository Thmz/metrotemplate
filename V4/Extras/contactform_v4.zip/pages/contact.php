<?php
$subNav = array(
	"Tutorials ; tutorials.php ; #FF8000;",
	"Contact ; contact.php ; #FF8000;",
	"Forum ; forum/ ; #FF8000;",
	
);
set_include_path("../");
include_once("inc/essentials.php");
?>
<script>
$mainNav.set("support");

$(document).ready(function(){
	$("#confirm_send").click(function(){
		if($("#email").val().length == 0){
			alert("You must fill in an email adress!");
		}else if($("#message").val().length<10){
			alert("Message must be longer than 10 characters!")
		}else if($("#message").val().length>400){
			alert("Message must be shorter than 400 characters!")
		}else if($("#test").val() != "1234"){
			alert("You must fill in '1234' without apostrophes");
		}else{
			$("#msgbox").removeClass().addClass('messagebox').text('Sending...').fadeIn(1000);
			$.post("ajax/contact.php",{ email:$("#email").val(),message:$("#message").val(),test:$("#test").val(),rand:Math.random() } ,function(data){
				if(data=='yes'){
					$("#msgbox").fadeTo(200,0.1,function(){
						$(this).html('Sent!').addClass('messageboxok').fadeTo(300,1,function(){
		                 });
						 $("#contactform").fadeOut(500,function(){$(this).html("<div class='messageboxok' id='msgbox' style='display:block;'>Message sent! We'll try to reply in 24 hours.</div>").fadeIn(500)});;
					});
				}else{
		           $("#msgbox").fadeTo(200,0.1,function(){
		           		$(this).html(data).addClass('messageboxerror').fadeTo(900,1);
		           });
		        }
		    });
		}
	});
});
</script>
<style>
.messagebox{
	background-color:#F90;
}
.messageboxok{
	background-color:#090;
}
.messageboxerror{
	background-color:#F00;	
}
#msgbox{
	border:1px solid #EEE;
	font-size: 13px;
	padding: 2px 4px;
	display:none;
	margin-left:15px;
	color:#FFF;
}
</style>

<h1 class="margin-t-0">Contact</h1>
<hr>
<p>Please use the forum for general questions! If you have a question that shouldn't be seen by everyone, contact me using this form :)
<br />
<br />
<div id="contactform">
<table border="0" cellspacing="0" width="500" cellpadding="5">
<tr><td>Your Email:</td><td><input type="text" style="width:350px;" id="email" /></td></tr>
<tr><td>Message:</td><td><textarea style="width:350px;height:150px;" id="message"></textarea></td></tr>
<tr><td></td><td style="padding-left:10px;"> Type "1234" here -> <input type="text" size="4" id="test" /></td></tr>
<tr><td></td><td style="padding-left:10px;"><button type="button" class="greenButton" id="confirm_send">Send</button><span id="msgbox"></span></td></tr>
</table>
</div>