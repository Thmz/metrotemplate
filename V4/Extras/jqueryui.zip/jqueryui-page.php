<script>
menuLink = new Array(); 
menuColor = new Array();
$mainNav.set("home");
</script>
<h1 style='margin-top:0px;'>jQuery UI</h1>
<hr class="margin-t-0" />
<em>For Metro UI Template 3.0.3</em>
    
<link type="text/css" href="jqueryui/css/ui-metro/jquery-ui-1.8.24.custom.css" rel="Stylesheet" />	<!-- CALLS THE THEME FILE -->
<script type="text/javascript" src="jqueryui/js/jquery-ui-1.8.24.custom.min.js"></script><!--CALLS THE JQUERY UI SOURCE FILE -->

<h2>Accordion</h2>
<em>Due to the behavior of jQuery UI's Accordion in a animated div, you must use the javascript code that's used here!</em>
<script>
$("#accordion").accordion({
	active:false
});
setTimeout(function(){ /* NEEDED FOR SCALING BUG in jQuery UI, see http://bugs.jqueryui.com/ticket/3905 */
	$("#accordion").accordion("resize");
},showSpeed+1);
</script>

<div id="accordion">
	<h3><a href="#">Section 1</a></h3>
	<div>
		<p>
		Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer
		ut neque. Vivamus nisi metus, molestie vel, gravida in, condimentum sit
		amet, nunc. Nam a nibh. Donec suscipit eros. Nam mi. Proin viverra leo ut
		odio. Curabitur malesuada. Vestibulum a velit eu ante scelerisque vulputate.
		</p>
	</div>
	<h3><a href="#">Section 2</a></h3>
	<div>
		<p>
		Sed non urna. Donec et ante. Phasellus eu ligula. Vestibulum sit amet
		purus. Vivamus hendrerit, dolor at aliquet laoreet, mauris turpis porttitor
		velit, faucibus interdum tellus libero ac justo. Vivamus non quam. In
		suscipit faucibus urna.
		</p>
	</div>
	<h3><a href="#">Section 3</a></h3>
	<div>
		<p>
		Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis.
		Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero
		ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis
		lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.
		</p>
		<ul>
			<li>List item one</li>
			<li>List item two</li>
			<li>List item three</li>
		</ul>
	</div>
	<h3><a href="#">Section 4</a></h3>
	<div>
		<p>
		Cras dictum. Pellentesque habitant morbi tristique senectus et netus
		et malesuada fames ac turpis egestas. Vestibulum ante ipsum primis in
		faucibus orci luctus et ultrices posuere cubilia Curae; Aenean lacinia
		mauris vel est.
		</p>
		<p>
		Suspendisse eu nisl. Nullam ut libero. Integer dignissim consequat lectus.
		Class aptent taciti sociosqu ad litora torquent per conubia nostra, per
		inceptos himenaeos.
		</p>
	</div>
</div>

<h2>Tabs</h2>
<script>
$(function() {
	$( "#tabs" ).tabs();
});
</script>
<div id="tabs">
	<ul>
		<li><a href="#tabs-1">Nunc tincidunt</a></li>
		<li><a href="#tabs-2">Proin dolor</a></li>
		<li><a href="#tabs-3">Aenean lacinia</a></li>
	</ul>
	<div id="tabs-1">
		<p>Proin elit arcu, rutrum commodo, vehicula tempus, commodo a, risus. Curabitur nec arcu. Donec sollicitudin mi sit amet mauris. Nam elementum quam ullamcorper ante. Etiam aliquet massa et lorem. Mauris dapibus lacus auctor risus. Aenean tempor ullamcorper leo. Vivamus sed magna quis ligula eleifend adipiscing. Duis orci. Aliquam sodales tortor vitae ipsum. Aliquam nulla. Duis aliquam molestie erat. Ut et mauris vel pede varius sollicitudin. Sed ut dolor nec orci tincidunt interdum. Phasellus ipsum. Nunc tristique tempus lectus.</p>
	</div>
	<div id="tabs-2">
		<p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
	</div>
	<div id="tabs-3">
		<p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
		<p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p>
	</div>
</div>

<h2>Slider</h2>
<h3>Normal slider</h3>
<script>
$(function() {
	$( "#slider" ).slider();
});
</script>

<div id="slider" style="width:150px;"></div>

<script>
/* Check value*/
$("#slider").bind( "slide", function(event, ui) {
  $("#sliderValue").html(ui.value);
});
</script>
<p>Value: <span id="sliderValue">0</span>


<h3>Vertical range slider</h3>
<script>
$(function() {
	$( "#slider-range" ).slider({
		orientation: "vertical",
		range: true,
		values: [ 17, 67 ],
		slide: function( event, ui ) {
			$( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
		}
	});
	$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
		" - $" + $( "#slider-range" ).slider( "values", 1 ) );
});
</script>
<p>
	<label for="amount">Target sales goal (Millions):</label>
	<input type="text" id="amount" style="border:0; color:#f6931f; font-weight:bold;" />
</p>
<div id="slider-range" style="height:150px;"></div>

<h2>Datepicker</h2>
<script>
$(function() {
	$( "#datepicker" ).datepicker();
});
</script>
<p>Date: <input type="text" id="datepicker"></p>


<h2>Buttons</h2>

<script>
$(function() {
	$( "input:submit, a, button", ".buttonsWrapper" ).button();
});
</script>
<div class="buttonsWrapper">
<button>A button element</button>
<input type="submit" value="A submit button"/>
<a href="#" onclick="javascript:return false;">An anchor</a>
</div>

<script>
$(function() {
	$( "#radio" ).buttonset();
});
</script>
<form>
	<div id="radio">
		<input type="radio" id="radio1" name="radio" /><label for="radio1">Choice 1</label>
		<input type="radio" id="radio2" name="radio" checked="checked" /><label for="radio2">Choice 2</label>
		<input type="radio" id="radio3" name="radio" /><label for="radio3">Choice 3</label>
	</div>
</form>


<script>
$(function() {
	$( "#check" ).button();
	$( "#format" ).buttonset();
});
</script>
<br />
<input type="checkbox" id="check" /><label for="check">Toggle</label>
<p>
<div id="format">
	<input type="checkbox" id="check1" /><label for="check1">B</label>
	<input type="checkbox" id="check2" /><label for="check2">I</label>
	<input type="checkbox" id="check3" /><label for="check3">U</label>
</div>

	
	<script>
	$(function() {
		$( ".otherButtons button:first" ).button({
            icons: {
                primary: "ui-icon-locked"
            },
            text: false
        }).next().button({
            icons: {
                primary: "ui-icon-locked"
            }
        }).next().button({
            icons: {
                primary: "ui-icon-gear",
                secondary: "ui-icon-triangle-1-s"
            }
        }).next().button({
            icons: {
                primary: "ui-icon-gear",
                secondary: "ui-icon-triangle-1-s"
            },
            text: false
        });
	});
	</script>
<div class="otherButtons">
<button>Button with icon only</button>
<button>Button with icon on the left</button>
<button>Button with two icons</button>
<button>Button with two icons and no text</button>
</div>

<style>
	#toolbar {
		padding: 10px 4px;
	}
	</style>
	<script>
	$(function() {
		$( "#beginning" ).button({
			text: false,
			icons: {
				primary: "ui-icon-seek-start"
			}
		});
		$( "#rewind" ).button({
			text: false,
			icons: {
				primary: "ui-icon-seek-prev"
			}
		});
		$( "#play" ).button({
			text: false,
			icons: {
				primary: "ui-icon-play"
			}
		})
		.click(function() {
			var options;
			if ( $( this ).text() === "play" ) {
				options = {
					label: "pause",
					icons: {
						primary: "ui-icon-pause"
					}
				};
			} else {
				options = {
					label: "play",
					icons: {
						primary: "ui-icon-play"
					}
				};
			}
			$( this ).button( "option", options );
		});
		$( "#stop" ).button({
			text: false,
			icons: {
				primary: "ui-icon-stop"
			}
		})
		.click(function() {
			$( "#play" ).button( "option", {
				label: "play",
				icons: {
					primary: "ui-icon-play"
				}
			});
		});
		$( "#forward" ).button({
			text: false,
			icons: {
				primary: "ui-icon-seek-next"
			}
		});
		$( "#end" ).button({
			text: false,
			icons: {
				primary: "ui-icon-seek-end"
			}
		});
		$( "#shuffle" ).button();
		$( "#repeat" ).buttonset();
	});
	</script>
<span id="toolbar" class="ui-widget-header ui-corner-all">
	<button id="beginning">go to beginning</button>
	<button id="rewind">rewind</button>
	<button id="play">play</button>
	<button id="stop">stop</button>
	<button id="forward">fast forward</button>
	<button id="end">go to end</button>
	
	<input type="checkbox" id="shuffle" /><label for="shuffle">Shuffle</label>
	
	<span id="repeat">
		<input type="radio" id="repeat0" name="repeat" checked="checked" /><label for="repeat0">No Repeat</label>
		<input type="radio" id="repeat1" name="repeat" /><label for="repeat1">Once</label>
		<input type="radio" id="repeatall" name="repeat" /><label for="repeatall">All</label>
	</span>
</span>


<script>
	$(function() {
		$( "#rerun" )
			.button()
			.click(function() {
				alert( "Running the last action" );
			})
			.next()
				.button( {
					text: false,
					icons: {
						primary: "ui-icon-triangle-1-s"
					}
				})
				.click(function() {
					alert( "Could display a menu to select an action" );
				})
				.parent()
					.buttonset();
	});
	</script>
<div>
	<button id="rerun">Run last action</button>
	<button id="select">Select an action</button>
</div>


<h2> Autocomplete</h2>
<script>
	$(function() {
		var availableTags = [
			"ActionScript",
			"AppleScript",
			"Asp",
			"BASIC",
			"C",
			"C++",
			"Clojure",
			"COBOL",
			"ColdFusion",
			"Erlang",
			"Fortran",
			"Groovy",
			"Haskell",
			"Java",
			"JavaScript",
			"Lisp",
			"Perl",
			"PHP",
			"Python",
			"Ruby",
			"Scala",
			"Scheme"
		];
		$( "#tags" ).autocomplete({
			source: availableTags
		});
	});
	</script>
<div class="ui-widget">
	<label for="tags">Tags: </label>
	<input id="tags">
</div>
<em>Type "ja" and see what comes</em>

<h2>Progressbar</h2>
<script>
	$(function() {
		$( "#progressbar" ).progressbar({
			value: 37
		});
	});
	</script>
<div id="progressbar" style="width:200px;"></div>


<h2>Dialog</h2>
<script>
$(function() {
	$("#dialog").dialog({
		autoOpen: false,
		show: "blind",
		hide:"blind",
	});
});
</script>
<div id="dialog" title="Basic dialog">
	<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
</div>


<script>
/*toggle dialog*/
$("#toggleDialog").click(function(){
	$("#dialog").dialog("open");
});
$("#toggleDialog").button();
</script>
<button id="toggleDialog">Show Dialog</button>

<script>
$(function() {
	$("#dialog-modal").dialog({
		autoOpen: false,
		modal: true
	});
});
</script>
<div id="dialog-modal" title="Modal dialog">
	<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
</div>

<script>
/*toggle dialog*/
$("#toggleDialogModal").click(function(){
	$("#dialog-modal").dialog("open");
});
$("#toggleDialogModal").button();
</script>
<button id="toggleDialogModal">Show Modal Dialog</button>