Drop the theme_tech folder into your /themes/ folder. Open config/layout.php

and change following vars to these values:


$theme = "theme_tech";

$bgColor = "#111"; 

$bgImage = "themes/theme_tech/img/background.jpg"; 




Recommend colors to use on your site are:

#BD6500   -> kind of dark orange (for tile labels etc)
#E87C00   -> kind of orange
#10668F   -> blue