Drop the "theme_v3" folder inside this zip into the themes folder of your Metro UI template.

Open config/layout.php and set $theme to "theme_v3", set $bgColor to "#DDD" and set $bgImage to "".
