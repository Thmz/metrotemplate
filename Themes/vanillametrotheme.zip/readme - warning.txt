
The style.css file must be in applications/dashboard/design/

the metro folder must be in themes/



Note that this is a very hacky theme, not finished at all. And I don't know if this works on every version of vanilla.

-Thomas Verelst