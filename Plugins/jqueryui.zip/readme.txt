see forum post ;)
Basically: just put the jqueryui-page.php in the pages folder, put the jquery folder in your root directory, and create a link to the jquery page and it should work.