<?php
$topMenu_Full = true;
$topMenu_Mobile = true;

$plBody .= call_user_func(function() use ($mobile, $topMenu_Full, $topMenu_Mobile){
	/* SETTINGS */
	$focus = true; // makes the other items darker
	$title = "Button";
	
	/*add your links here */
	$links = array();
	$links["Test"] = "../test.php";
	$links["Another title"] = "/anotherpage.php";
	
	/*END OF SETTINGS*/
	$c = '';
	if(($mobile && $topMenu_Mobile)||(!$mobile&&$topMenu_Full)){
		$c.="<div id='topMenu'><div id='topButton'>".$title."</div><ul id='topUl'>";
		foreach($links as $title=>$link){
			$c.="<li><a href='".$link."'>".$title."</a></li>";
		}
		$c.="</ul></div>";
	}
	if($focus){
		$c.="<div id='topMenuFocus'></div>";
	}
	return $c;
});
if($topMenu_Full && !$mobile){
	$cssFiles[] = "plugins/topmenu/menutop.css";
}
if($topMenu_Mobile && $mobile){
	$cssFiles[] = "plugins/topmenu/menutopmob.css";
}
?>