$(document).on("click","#topButton",function(){
	if($("#topUl").css("display")=="none"){
		$("#topUl").stop().fadeIn(300)
		$("#topButton").css("text-decoration","underline");	
		if($('#topMenuFocus').length != 0){
			$("html").not($("#topUl")).not($("#topButton")).bind("click.topMenu",function(){
				$("#topUl,#topMenuFocus").stop().fadeOut(300);
			});
			$('#topMenuFocus').stop().fadeIn(300);
		}
	}else{
		$("#topUl,#topMenuFocus").stop().fadeOut(300)
		$("#topButton").css("text-decoration","none");
		$("html").unbind("click.topMenu");
	}	
});