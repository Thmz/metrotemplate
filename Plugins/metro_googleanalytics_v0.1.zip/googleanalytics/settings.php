<?php
//SETTINGS
$propertyID = "XX-12345678-1";
/*you can find this by opening your Google Analytics, selecting your site (so you get your visitor graphs), and then click on the Administrator button on the right top. Then you'll see on that page the property ID under the site title;*/
?>