$.plugin($afterSubPageLoad,{
	googleanalytics:function(){
		 if (typeof _gaq !== "undefined" && _gaq !== null) {
			  _gaq.push(['_trackPageview', "/#!/"+$hashed.current]);
		 }
	}
});