<?php
/* DISPLAYS LANGUAGE FLAGS */

/*SETTINGS */

$languages = array();
$languages['English'] = ''; // root folder
$languages['Dutch'] = '/nl/'; // dutch
$languages['French'] = '/fr/'; // french

// add and remove languages like the example: $languages['title'] = 'url';  The URL part MUST have 2 letters, the amount of slashes doesn't matter.

$languageFlags = array();
$languageFlags['English'] = 'img/english.gif';
$languageFlags['Dutch'] = 'img/dutch.gif';
$languageFlags['French'] = 'img/france.gif';



/* END OF SETTINGS */
$currentLang = "";
$langPart = substr($_SERVER['REQUEST_URI'],0,4); // get part after domain, includeding first / slash.
if($langPart{0} != "/"){
	$langPart = "/".$langPart;
}
if($langPart[strlen($langPart)-1] != "/"){
	$langPart .="/";
}
foreach($languages as $key=>$language){
	if($language != ''){
		if($language{0} != "/"){
			$language = "/".$language;
		}
		if($language[strlen($language)-1] != "/"){
			$language .="/";
		}
		if($langPart==$language){
			$currentLang = $key;
			break;
		}
	}
}
if($currentLang == ""){
	reset($languages);
	$currentLang = key($languages);
}
if($mobile){
	$cssMargintop = "<style>#subNavWrapper{margin-top:25px;} #lang{top:-28px;]</style>";
}else{
	$cssMargintop = "";
}
$plContentWrapper.="".$cssMargintop." <div id='lang'><div id='currentLang'><img src='".$languageFlags[$currentLang]."' width='20'><div>".$currentLang."</div></div><ul>";
foreach($languages as $title=>$link){
	if($title!=$currentLang){
		$plContentWrapper.="<li><a href='".$link."'><img src='".$languageFlags[$title]."' width='20'>".$title."</a></li>";
	}
}
$plContentWrapper.="</ul></div>";
?>