/*Creates a fake title, use y value -0.4 to display it at the right height */
/*To hide the a grouptitle, use the following code, and replace the 0 by the number you want (0 is the firs group, 1 the second etc);
$.plugin($afterTilesAppend,{
	fakeTitle:function(){
		$(".titleGroup0").hide();
	}
});
*/
tileFakeTitle = function(group,x,y,width,height,bg,linkPage,titleText,optClass){ // make your own tiles
	$page.content += (
	"<a "+makeLink(linkPage)+" class='tileFakeTitle noClick tile group"+group+" "+optClass+"' style=' \
	margin-top:"+((y*$tile.scalespacing)+45)+"px;margin-left:"+(x*$tile.scalespacing+group*$group.spacing)+"px; \
	width: auto; height:"+(0.4*$tile.scalespacing-$tile.spacing)+"px;'>\
	<div id='fakeTitle'>\
	<h3>Test</h3>\
	</div>\
	</a>");
}